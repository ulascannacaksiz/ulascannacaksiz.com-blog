﻿    <section class="content container-fluid">
    <form action="?sayfa=kayit&islem=kayit" method="post">
    <div class="form-group col-md-4">
	<label>İsim</label>
    <input type="text" class="form-control" name="isim">
    <label>Soyisim</label>
    <input type="text" class="form-control" name="soyisim">
    <label>Eposta</label>
    <input type="text" class="form-control" name="eposta">
    <label>Şifre</label>
    <input type="text" class="form-control" name="sifre"><br>
    <input type="submit" class="btn btn-success" value="Kullanıcıyı Kaydet">
		</div>
		</form>